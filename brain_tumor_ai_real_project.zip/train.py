import argparse
from pathlib import Path
import copy
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm

from dataset import get_datasets
from model import build_model

def evaluate(model, loader, criterion, device):
    model.eval()
    loss_total = 0
    correct = 0
    total = 0
    y_true, y_pred = [], []

    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(device), y.to(device)
            out = model(x)
            loss = criterion(out, y)

            loss_total += loss.item() * x.size(0)
            pred = out.argmax(1)
            correct += (pred == y).sum().item()
            total += y.size(0)

            y_true.extend(y.cpu().numpy())
            y_pred.extend(pred.cpu().numpy())

    return loss_total / total, correct / total, y_true, y_pred

def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    train_full, test_ds = get_datasets(args.data)

    # Fixed validation split from the training directory.
    val_size = max(1, int(len(train_full) * 0.15))
    train_size = len(train_full) - val_size

    generator = torch.Generator().manual_seed(42)
    train_ds, val_ds = random_split(
        train_full, [train_size, val_size], generator=generator
    )

    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True,
                              num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False,
                            num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=args.batch_size, shuffle=False,
                             num_workers=0)

    model = build_model().to(device)

    # Start by training the classifier head.
    for p in model.parameters():
        p.requires_grad = False
    for p in model.fc.parameters():
        p.requires_grad = True

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(
        filter(lambda p: p.requires_grad, model.parameters()),
        lr=args.lr,
        weight_decay=1e-4
    )

    best_acc = 0.0
    best_state = None
    patience_counter = 0
    history = {"train_loss": [], "val_loss": [], "val_acc": []}

    for epoch in range(args.epochs):
        model.train()
        running = 0.0
        total = 0

        loop = tqdm(train_loader, desc=f"Epoch {epoch+1}/{args.epochs}")
        for x, y in loop:
            x, y = x.to(device), y.to(device)

            optimizer.zero_grad()
            out = model(x)
            loss = criterion(out, y)
            loss.backward()
            optimizer.step()

            running += loss.item() * x.size(0)
            total += x.size(0)
            loop.set_postfix(loss=f"{loss.item():.4f}")

        train_loss = running / total
        val_loss, val_acc, _, _ = evaluate(model, val_loader, criterion, device)

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)

        print(f"Train loss: {train_loss:.4f} | Val loss: {val_loss:.4f} | Val acc: {val_acc:.4%}")

        if val_acc > best_acc:
            best_acc = val_acc
            best_state = copy.deepcopy(model.state_dict())
            patience_counter = 0
            Path("models").mkdir(exist_ok=True)
            torch.save(best_state, "models/best_model.pth")
            print("Saved new best model.")
        else:
            patience_counter += 1

        if patience_counter >= args.patience:
            print("Early stopping.")
            break

    # Fine-tune the full pretrained network for a few epochs.
    print("\nFine-tuning the full network...")
    if best_state is not None:
        model.load_state_dict(best_state)

    for p in model.parameters():
        p.requires_grad = True

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.fine_lr, weight_decay=1e-4)

    for epoch in range(args.fine_epochs):
        model.train()
        running = 0.0
        total = 0
        loop = tqdm(train_loader, desc=f"Fine-tune {epoch+1}/{args.fine_epochs}")

        for x, y in loop:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad()
            out = model(x)
            loss = criterion(out, y)
            loss.backward()
            optimizer.step()

            running += loss.item() * x.size(0)
            total += x.size(0)

        val_loss, val_acc, _, _ = evaluate(model, val_loader, criterion, device)
        print(f"Fine-tune loss: {running/total:.4f} | Val acc: {val_acc:.4%}")

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save(model.state_dict(), "models/best_model.pth")

    # Final test evaluation.
    model.load_state_dict(torch.load("models/best_model.pth", map_location=device))
    test_loss, test_acc, y_true, y_pred = evaluate(model, test_loader, criterion, device)

    labels = test_ds.classes
    report = classification_report(y_true, y_pred, target_names=labels, digits=4)
    cm = confusion_matrix(y_true, y_pred)

    Path("results").mkdir(exist_ok=True)
    Path("results/classification_report.txt").write_text(
        f"Test accuracy: {test_acc:.4%}\n\n{report}",
        encoding="utf-8"
    )

    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=labels, yticklabels=labels)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Brain Tumor MRI Confusion Matrix")
    plt.tight_layout()
    plt.savefig("results/confusion_matrix.png", dpi=160)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.plot(history["train_loss"], label="Train loss")
    plt.plot(history["val_loss"], label="Validation loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.tight_layout()
    plt.savefig("results/training_loss.png", dpi=160)
    plt.close()

    print("\n" + "=" * 60)
    print(f"FINAL TEST ACCURACY: {test_acc:.2%}")
    print("=" * 60)
    print(report)
    print("\nSaved model: models/best_model.pth")
    print("Saved evaluation files in results/")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--fine-epochs", type=int, default=3)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--fine-lr", type=float, default=1e-5)
    parser.add_argument("--patience", type=int, default=2)
    args = parser.parse_args()
    main(args)
