import argparse
from pathlib import Path
import torch
from PIL import Image
from torchvision import transforms

from model import build_model

CLASSES = ["glioma", "meningioma", "notumor", "pituitary"]

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406],
                         [0.229, 0.224, 0.225]),
])

def predict(image_path):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_path = Path("models/best_model.pth")

    if not model_path.exists():
        raise FileNotFoundError("Train the model first: python train.py")

    model = build_model().to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()

    image = Image.open(image_path).convert("RGB")
    x = transform(image).unsqueeze(0).to(device)

    with torch.no_grad():
        probs = torch.softmax(model(x), dim=1)[0]
        idx = int(probs.argmax())

    return CLASSES[idx], float(probs[idx]), {
        CLASSES[i]: float(probs[i]) for i in range(len(CLASSES))
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    args = parser.parse_args()

    label, confidence, probabilities = predict(args.image)

    print("\n" + "=" * 50)
    print("BRAIN MRI PREDICTION")
    print("=" * 50)
    print(f"Prediction : {label}")
    print(f"Confidence : {confidence:.2%}")
    print("\nClass probabilities:")
    for name, p in probabilities.items():
        print(f"  {name:12s}: {p:.2%}")
    print("\nThis is a research/educational model, not a clinical diagnosis.")
