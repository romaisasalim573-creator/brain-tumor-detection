from pathlib import Path
import shutil
import kagglehub

DATA_DIR = Path("data")
HANDLE = "masoudnickparvar/brain-tumor-mri-dataset"

def main():
    DATA_DIR.mkdir(exist_ok=True)
    print("Downloading Brain Tumor MRI Dataset from Kaggle...")
    path = kagglehub.dataset_download(HANDLE)
    source = Path(path)

    print(f"Downloaded dataset to: {source}")

    # If KaggleHub already exposes Training/Testing, copy them into ./data.
    for name in ["Training", "Testing"]:
        candidates = list(source.rglob(name))
        if candidates:
            destination = DATA_DIR / name
            if destination.exists():
                print(f"{destination} already exists; skipping copy.")
            else:
                shutil.copytree(candidates[0], destination)
                print(f"Copied {name} -> {destination}")

    print("\nExpected structure:")
    print("data/Training/{glioma,meningioma,notumor,pituitary}")
    print("data/Testing/{glioma,meningioma,notumor,pituitary}")
    print("\nIf the folders were not copied automatically, extract the Kaggle ZIP manually into ./data.")

if __name__ == "__main__":
    main()
