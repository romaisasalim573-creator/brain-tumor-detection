from pathlib import Path
from torchvision import datasets, transforms

CLASS_NAMES = ["glioma", "meningioma", "notumor", "pituitary"]

def get_transforms(train=True):
    if train:
        return transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(10),
            transforms.ColorJitter(brightness=0.15, contrast=0.15),
            transforms.RandomAffine(degrees=0, translate=(0.05, 0.05), scale=(0.95, 1.05)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406],
                                 [0.229, 0.224, 0.225]),
        ])

    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406],
                             [0.229, 0.224, 0.225]),
    ])

def get_datasets(data_dir="data"):
    root = Path(data_dir)
    train_dir = root / "Training"
    test_dir = root / "Testing"

    if not train_dir.exists() or not test_dir.exists():
        raise FileNotFoundError(
            "Dataset not found. Put Training/ and Testing/ inside the data/ folder "
            "or run python download_dataset.py."
        )

    train_ds = datasets.ImageFolder(train_dir, transform=get_transforms(True))
    test_ds = datasets.ImageFolder(test_dir, transform=get_transforms(False))

    return train_ds, test_ds
