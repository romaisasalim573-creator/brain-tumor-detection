import torch.nn as nn
from torchvision.models import resnet18, ResNet18_Weights

NUM_CLASSES = 4

def build_model():
    model = resnet18(weights=ResNet18_Weights.DEFAULT)

    # MRI images are commonly grayscale, but ImageFolder gives RGB tensors.
    # Keeping the pretrained RGB input lets us benefit from ImageNet features.
    in_features = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Dropout(0.35),
        nn.Linear(in_features, NUM_CLASSES)
    )
    return model
