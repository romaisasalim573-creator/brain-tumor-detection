# Brain Tumor MRI AI Classifier

A real deep-learning project for **4-class brain MRI classification**:
- Glioma
- Meningioma
- Pituitary
- No Tumor

The project uses transfer learning with **ResNet18 pretrained on ImageNet**, data augmentation, validation, class weighting, early stopping, test evaluation, confusion matrix, and an interactive Gradio prediction interface.

## Dataset

This project is designed for the Kaggle **Brain Tumor MRI Dataset** by Masoud Nickparvar:
https://www.kaggle.com/datasets/masoudnickparvar/brain-tumor-mri-dataset

The dataset contains Training/ and Testing/ folders with the four classes.

## 1. Install

Use Python 3.10 or newer.

```bash
pip install -r requirements.txt
```

## 2. Download the dataset

You can download it manually from Kaggle and extract it into:

```text
data/
├── Training/
│   ├── glioma/
│   ├── meningioma/
│   ├── notumor/
│   └── pituitary/
└── Testing/
    ├── glioma/
    ├── meningioma/
    ├── notumor/
    └── pituitary/
```

Or run:

```bash
python download_dataset.py
```

Kaggle may require authentication for downloading public resources from a normal local Python environment.

## 3. Train

```bash
python train.py
```

For a quick test:

```bash
python train.py --epochs 2 --batch-size 16
```

For a stronger run:

```bash
python train.py --epochs 10 --batch-size 32
```

Training creates:

```text
models/best_model.pth
results/training_history.png
results/confusion_matrix.png
results/classification_report.txt
```

## 4. Predict one MRI

```bash
python predict.py --image "path/to/mri.jpg"
```

Example:

```bash
python predict.py --image "data/Testing/glioma/Te-gl_0010.jpg"
```

## 5. Launch the interface

After training:

```bash
python app.py
```

Then open the local Gradio URL shown in the terminal.

## Important

This is a research/educational machine-learning project. It is **not a clinically validated medical diagnostic device**. A high test accuracy on a public image dataset does not establish clinical accuracy on real patients.
