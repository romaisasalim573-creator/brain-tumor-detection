import gradio as gr
from predict import predict

def classify(image):
    if image is None:
        return "Please upload an MRI image.", {}

    label, confidence, probabilities = predict(image)
    return f"{label.upper()} — {confidence:.2%} confidence", probabilities

demo = gr.Interface(
    fn=classify,
    inputs=gr.Image(type="filepath", label="Upload Brain MRI"),
    outputs=[
        gr.Textbox(label="Prediction"),
        gr.Label(label="Class probabilities")
    ],
    title="Brain Tumor MRI AI Classifier",
    description="4-class research model: Glioma, Meningioma, Pituitary, No Tumor."
)

if __name__ == "__main__":
    demo.launch()
